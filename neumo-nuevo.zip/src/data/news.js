export const news = [
  {
    title: 'Repudio a publicidades de tabaco que violan la Ley 26.687',
    date: '2023',
    link: 'https://www.neumo-argentina.org/images/noticias/2023/gacetilla_prensa_dic_2023.docx',
  },
  {
    title: 'Primera cirugía robótica de tórax por incisión única en Argentina',
    date: '2022',
    link: 'https://tn.com.ar/salud/noticias/2022/07/21/realizaron-la-primera-cirugia-robotica-de-torax-por-incision-unica-en-la-argentina/',
  },
  {
    title: 'Fumar duplica riesgo de progresión de COVID-19',
    date: '2020',
    link: 'https://www.agenciacyta.org.ar/2020/05/fumar-se-asociaria-al-doble-de-riesgo-de-sufrir-progresion-de-covid-19/',
  },
]


