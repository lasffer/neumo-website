export const partners = [
  { name: 'UATA', link: 'http://www.uata.org.ar' },
  { name: 'AAIBA', link: 'http://www.aaiba.org.ar/' },
  { name: 'LALCEC', link: 'http://www.lalcec.org.ar' },
  { name: 'SAMT', link: 'http://www.samt.com.ar/' },
  { name: 'Fundación Vacunar', link: 'https://vacunar.com.ar/' },
  { name: 'Rotary', link: 'http://www.lamorindasunrise.com/' },
  { name: 'Fundación Respirar', link: 'http://www.fundacionrespirar.org/' },
  { name: 'CIFS', link: 'http://www.cifs.dk' },
]


